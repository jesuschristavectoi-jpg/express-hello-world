# AAPHAA — plateforme ONG internationale

## Fonctionnalités
- Site responsive moderne
- Français / English / Español / العربية
- API Node/Express
- Base SQLite pour actualités, projets, médias, donateurs et intentions de dons
- Tableau d'administration
- Galerie images/vidéos
- Formulaire donateur
- Module d'intention de don prêt à connecter à un prestataire de paiement

## Installation
Node.js 18+ recommandé.

```bash
npm install
node server.js
```

Puis ouvrir `http://localhost:3000`.

Administration : `http://localhost:3000/admin`

## Sécurité
La clé `demo-admin` est uniquement une démonstration. En production, utiliser une vraie authentification (sessions/JWT + hash de mots de passe), HTTPS, protection CSRF, validation stricte, limitation de débit et gestion sécurisée des secrets.

## Paiements
Le module de dons enregistre une intention de don mais ne débite aucun compte. Connecter un prestataire certifié et disponible dans le pays ciblé avant toute mise en production.

## Données
Les chiffres d'impact ne sont pas inventés. Les coordonnées, partenaires, projets, chiffres et contenus doivent être validés par AAPHAA avant publication.
