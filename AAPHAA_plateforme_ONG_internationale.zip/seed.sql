INSERT INTO projects(name_fr,name_en,name_es,name_ar,description_fr,status) VALUES
('Inclusion & Autonomie','Inclusion & Autonomy','Inclusión y Autonomía','الإدماج والاستقلالية','Programme favorisant la participation sociale et la valorisation des capacités.','active'),
('Bien vieillir','Healthy Ageing','Envejecer con dignidad','الشيخوخة بكرامة','Programme d’accompagnement des personnes âgées.','active');
