const key=()=>document.querySelector("#key").value, msg=s=>document.querySelector("#adminMsg").textContent=s;
async function post(url,form){let b=Object.fromEntries(new FormData(form));let r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json","x-admin-key":key()},body:JSON.stringify(b)});let j=await r.json();msg(j.error||"Opération terminée.");form.reset()}
document.querySelector("#newsForm").onsubmit=e=>{e.preventDefault();post("/api/news",e.target)};
document.querySelector("#projectForm").onsubmit=e=>{e.preventDefault();post("/api/projects",e.target)};
document.querySelector("#mediaForm").onsubmit=e=>{e.preventDefault();post("/api/media",e.target)};